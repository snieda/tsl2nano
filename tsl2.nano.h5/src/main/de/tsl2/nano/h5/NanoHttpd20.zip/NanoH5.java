package de.tsl2.nano.h5;

import static de.tsl2.nano.bean.def.IBeanCollector.MODE_CREATABLE;
import static de.tsl2.nano.bean.def.IBeanCollector.MODE_EDITABLE;
import static de.tsl2.nano.bean.def.IBeanCollector.MODE_MULTISELECTION;
import static de.tsl2.nano.bean.def.IBeanCollector.MODE_SEARCHABLE;
import static de.tsl2.nano.h5.NanoHTTPD.Method.GET;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.Stack;

import org.apache.commons.logging.Log;

import de.tsl2.nano.Environment;
import de.tsl2.nano.Messages;
import de.tsl2.nano.bean.BeanContainer;
import de.tsl2.nano.bean.IBeanContainer;
import de.tsl2.nano.bean.def.Bean;
import de.tsl2.nano.bean.def.BeanCollector;
import de.tsl2.nano.bean.def.BeanDefinition;
import de.tsl2.nano.bean.def.BeanPresentationHelper;
import de.tsl2.nano.bean.def.BeanValue;
import de.tsl2.nano.bean.def.IPageBuilder;
import de.tsl2.nano.bean.def.IPresentable;
import de.tsl2.nano.bean.def.SecureAction;
import de.tsl2.nano.collection.MapUtil;
import de.tsl2.nano.exception.FormattedException;
import de.tsl2.nano.exception.ForwardedException;
import de.tsl2.nano.execution.CompatibilityLayer;
import de.tsl2.nano.execution.SystemUtil;
import de.tsl2.nano.h5.NanoHTTPD.Response.Status;
import de.tsl2.nano.h5.navigation.EntityBrowser;
import de.tsl2.nano.h5.navigation.IBeanNavigator;
import de.tsl2.nano.h5.navigation.Workflow;
import de.tsl2.nano.log.LogFactory;
import de.tsl2.nano.persistence.HibernateBeanContainer;
import de.tsl2.nano.persistence.Persistence;
import de.tsl2.nano.persistence.PersistenceClassLoader;
import de.tsl2.nano.script.ScriptTool;
import de.tsl2.nano.service.util.BeanContainerUtil;
import de.tsl2.nano.serviceaccess.Authorization;
import de.tsl2.nano.serviceaccess.IAuthorization;
import de.tsl2.nano.util.FileUtil;
import de.tsl2.nano.util.StringUtil;

/**
 * An Application of subclassing NanoHTTPD to make a custom HTTP server.
 * 
 * <pre>
 * TODO:
 * - Bean-->BeanValue-->getColumnDefinition() --> Table(columns)
 * - PageBuilder --> Bean.Presentable
 * - Navigation
 * - Verbindung/Abgrenzung BeanContainer
 * - evtl mini-browser wie lynx einbinden
 * - BeanContainer mit cache fuer tests
 * </pre>
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class NanoH5 extends NanoHTTPD {
    private static final Log LOG = LogFactory.getLog(NanoH5.class);

    Map<String, NanoH5Session> sessions;

    IPageBuilder<?, String> builder;
    URL serviceURL;
    ClassLoader appstartClassloader;

    private static final String DEGBUG_HTML_FILE = "application.html";
    static final String START_PAGE = "Start";
    static final int OFFSET_FILTERLINES = 2;

    public NanoH5() throws IOException {
        this(Environment.get("http.connection", "localhost:8067"), Environment.get(IPageBuilder.class));
    }

    public NanoH5(String serviceURL, IPageBuilder<?, String> builder) throws IOException {
        super(getPort(serviceURL)/*, new File(Environment.getConfigPath())*/);
        this.serviceURL = getServiceURL(serviceURL);
        this.builder = builder != null ? builder : createPageBuilder();
        ResourceBundle bundle = ResourceBundle.getBundle(NanoH5.class.getPackage().getName() + ".messages",
            Locale.getDefault(),
            Thread.currentThread().getContextClassLoader());
        Messages.registerBundle(bundle, false);
        appstartClassloader = Thread.currentThread().getContextClassLoader();
        Environment.addService(ClassLoader.class, appstartClassloader);
        sessions = new LinkedHashMap<String, NanoH5Session>();
    }

    /**
     * main
     * 
     * @param args
     */
    public static void main(String[] args) {
        startApplication(NanoH5.class, MapUtil.asMap(0, "http.connection"), args);
    }

    /**
     * starts application and shows initial html page
     */
    @Override
    public void start() {
        try {
            super.start();
            LogFactory.setLogLevel(LogFactory.LOG_ALL);
            LOG.info(System.getProperties());
            createStartPage(DEGBUG_HTML_FILE);
            LOG.info("Listening on port " + serviceURL.getPort() + ". Hit Enter to stop.\n");
            if (System.getProperty("os.name").startsWith("Windows"))
                SystemUtil.executeRegisteredWindowsPrg("application.html");
            System.in.read();
        } catch (Exception ioe) {
            LOG.error("Couldn't start server:", ioe);
            stop();
//            System.exit(-1);
        }
    }

    public static URL getServiceURL(String serviceURLString) {
        if (serviceURLString == null)
            serviceURLString = Environment.get("service.url", "http://localhost:8067");
        if (!serviceURLString.matches(".*[:][0-9]{4,4}"))
            serviceURLString = "localhost:" + serviceURLString;
        if (!serviceURLString.contains("://"))
            serviceURLString = "http://" + serviceURLString;
        URL serviceURL = null;
        try {
            serviceURL = new URL(serviceURLString);
        } catch (MalformedURLException e) {
            ForwardedException.forward(e);
        }
        return serviceURL;
    }

    public static int getPort(String serviceURL) {
        return Integer.valueOf(StringUtil.substring(serviceURL, ":", null));
    }

    /**
     * createStartPage
     * 
     * @param resultHtmlFile
     */
    protected void createStartPage(String resultHtmlFile) {
        InputStream stream = Environment.getResource("start.template");
        String startPage = String.valueOf(FileUtil.getFileData(stream, null));
        startPage = StringUtil.insertProperties(startPage,
            MapUtil.asMap("url", serviceURL, "name", Environment.getName()));
        FileUtil.writeBytes(startPage.getBytes(), resultHtmlFile, false);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response serve(IHTTPSession s) {
        if (s.getMethod().equals(GET) && s.getUri().contains("."))
            return super.serve(s);
        parseBody(s);
//        InetAddress requestor = ((Socket) s.getHeaders().get("socket")).getInetAddress();
        String requestor = s.getHeaders().get("http-client-ip");
        NanoH5Session session = sessions.get(requestor);
        if (session == null) {
            session = createSession(requestor);
            //on a new session, no parameter should be set

        } else {//perhaps session was interrupted/close but not removed
            if (session.nav == null || session.nav.isEmpty()) {
                sessions.remove(session.inetAddress);
                session = createSession(requestor);
            }
        }
        return session.serve(s);
    }

    /**
     * fill body parameters (POST method) to parms
     * @param s session
     */
    private void parseBody(IHTTPSession s) {
        try {
            s.parseBody(s.getParms());
        } catch (Exception e) {
            ForwardedException.forward(e);
        }
    }

    public Response createResponse(String msg) {
        return createResponse(Status.OK, MIME_HTML, msg);
    }

    public Response createResponse(Status status, String type, String msg) {
        return new NanoHTTPD.Response(status, type, msg);
    }

    /**
     * adds services for presentation and page-builder
     */
    protected IPageBuilder<?, String> createPageBuilder() {
        Html5Presentation pageBuilder = new Html5Presentation();
        Environment.addService(BeanPresentationHelper.class, pageBuilder);
        Environment.addService(IPageBuilder.class, pageBuilder);
        return pageBuilder;
    }

    /**
     * initialize navigation model and perhaps bean-definitions. overwrite this method if you create your extending
     * application. this method will be called, before any bean types are loaded!
     */
    protected NanoH5Session createSession(String requestor) {
        LOG.info("creating new session on socket: " + requestor);
        NanoH5Session session = new NanoH5Session(this,
            requestor,
            createGenericNavigationModel(),
            Environment.get(ClassLoader.class));
        sessions.put(requestor, session);
        return session;
    }

    /**
     * reads all classes of 'beanjar', creates a root beancollector holding a collection of this classes.
     * 
     * @param beanjar jar to resolve the desired entities from
     * @return navigation stack holding a beancollector for all entity classes inside beanjar
     */
    protected IBeanNavigator createGenericNavigationModel() {

        BeanContainer.initEmtpyServiceActions();
        /*
         * create the presentable navigation stack
         */
        Bean<?> login = createPersistenceUnit();

        Workflow workflow = Environment.get(Workflow.class);
        
//        Sample Workflow
//        LinkedList<BeanAct> acts = new LinkedList<BeanAct>();
//        Parameter p = new Parameter();
//        p.put("project", true);
//        p.put("prjname", "test");
//        acts.add(new BeanAct("timesByProject",
//            "project&true",
//            "select t from Times t where t.project.id = :prjname",
//            p,
//            "prjname"));
//        workflow = new Workflow(acts);
//        Environment.persist(workflow);
//        
        if (workflow == null || workflow.isEmpty()) {
            LOG.debug("creating navigation stack");
            Stack<BeanDefinition<?>> navigationModel = new Stack<BeanDefinition<?>>();
            navigationModel.push(Bean.getBean(START_PAGE));
            navigationModel.push(login);
            return new EntityBrowser(navigationModel);
        } else {
            workflow.setLogin(login);
            return workflow;
        }
    }

    @SuppressWarnings({ "serial" })
    private Bean<?> createPersistenceUnit() {
        final Persistence persistence = Persistence.current();
        Bean<?> login = new Bean(persistence);
        login.removeAttributes("jdbcProperties");
        login.getAttribute("jarFile").getPresentation().setType(IPresentable.TYPE_ATTACHMENT);
        login.getPresentationHelper().change(BeanPresentationHelper.PROP_DESCRIPTION,
            Environment.translate("jarFile.tooltip", true),
            "jarFile");
        login.getPresentationHelper().change(BeanPresentationHelper.PROP_NULLABLE, false);
        login.getPresentationHelper().change(BeanPresentationHelper.PROP_NULLABLE, true, "connectionPassword");

        login.addAction(new SecureAction<Object>("tsl2nano.login.ok") {

            @Override
            public Object action() throws Exception {
                persistence.save();

                //define a new classloader to access all beans of given jar-file
                PersistenceClassLoader runtimeClassloader = new PersistenceClassLoader(new URL[0],
                    Thread.currentThread().getContextClassLoader());
                runtimeClassloader.addLibraryPath(Environment.getConfigPath());
                Thread.currentThread().setContextClassLoader(runtimeClassloader);
                Environment.addService(ClassLoader.class, runtimeClassloader);

                createAuthorization(persistence);

                //load all beans from selected jar-file and provide them in a beancontainer
                List<Class> beanClasses = createBeanContainer(persistence, runtimeClassloader);

                //create navigation model holding all bean types on first page after login
                return createBeanCollectors(beanClasses);
            }

            @Override
            public String getImagePath() {
                return "icons/open.png";
            }

            @Override
            public boolean isDefault() {
                return true;
            }
        });
        return login;
    }

    /**
     * createSubject
     * 
     * @param persistence
     * @return
     */
    private void createAuthorization(final Persistence persistence) {
        String userName = persistence.getConnectionUserName();
        Environment.addService(IAuthorization.class, Authorization.create(userName, false));
    }

    /**
     * after the creation of a new classloader and a beancontainer providing access to the new loaded bean types, this
     * method creates entries for all bean-types to the navigation stack. overwrite this method to define own
     * bean-collector handling.
     * 
     * @param beanClasses new loaded bean types
     * @return a root bean-collector holding all bean-type collectors.
     */
    protected BeanDefinition<?> createBeanCollectors(List<Class> beanClasses) {
        LOG.debug("creating collector for: ");
        List types = new ArrayList(beanClasses.size());
        for (Class cls : beanClasses) {
            LOG.debug("creating collector for: " + cls);
            BeanCollector collector = BeanCollector.getBeanCollector(cls, null, MODE_EDITABLE | MODE_CREATABLE
                | MODE_MULTISELECTION
                | MODE_SEARCHABLE, null);
//            collector.setPresentationHelper(new Html5Presentation(collector));
            types.add(collector);
        }
        /*
         * Perhaps show the script tool to do direct sql or ant
         */
        if (Environment.get("application.show.scripttool", true)) {
            ScriptTool tool = new ScriptTool();
            Bean beanTool = new Bean(tool);
            beanTool.setAttributeFilter("text", "result", "resourceFile", "selectionAction");
            beanTool.getAttribute("text").getPresentation().setType(IPresentable.TYPE_INPUT_MULTILINE);
            beanTool.getAttribute("result").getPresentation().setType(IPresentable.TYPE_TABLE);
            beanTool.getAttribute("sourceFile").getPresentation().setType(IPresentable.TYPE_ATTACHMENT);
            beanTool.getAttribute("selectedAction").setRange(tool.availableActions());
            beanTool.addAction(tool.runner());
            types.add(beanTool);
        }
        BeanCollector root = new BeanCollector(BeanCollector.class, types, MODE_EDITABLE | MODE_SEARCHABLE, null);
        root.setName(StringUtil.toFirstUpper(StringUtil.substring(Persistence.current().getJarFile(), "/", ".jar", true)));
        root.setAttributeFilter("name");
        root.getAttribute("name").setFormat(new Format() {
            /** serialVersionUID */
            private static final long serialVersionUID = 1725704131355509738L;

            @Override
            public StringBuffer format(Object obj, StringBuffer toAppendTo, FieldPosition pos) {
                String name = StringUtil.substring((String) obj, null, BeanCollector.POSTFIX_COLLECTOR);
                toAppendTo.append(Environment.translate(name, true));
                pos.setEndIndex(1);
                return toAppendTo;
            }

            @Override
            public Object parseObject(String source, ParsePosition pos) {
                return null;
            }
        });
        return root;
    }

    /**
     * createBeanContainer
     * 
     * @param persistence
     * @param runtimeClassloader
     * @return
     */
    protected List<Class> createBeanContainer(final Persistence persistence, PersistenceClassLoader runtimeClassloader) {
        if (!new File(persistence.getJarFile()).exists()) {
            //TODO: show generation message before - get script exception from exception handler
            generateJarFile(persistence.getJarFile());
            if (!new File(persistence.getJarFile()).exists()) {
                throw new FormattedException("Couldn't generate bean jar file '" + persistence.getJarFile()
                    + "' through script hibtools.xml! Please see log file for exceptions.");
            }
        }

        List<Class> beanClasses = runtimeClassloader.loadBeanClasses(persistence.getJarFile(), null);
        Environment.setProperty("loadedBeanTypes", beanClasses);

        if (Environment.get("use.applicationserver", false))
            BeanContainerUtil.initGenericServices(runtimeClassloader);
        else
            HibernateBeanContainer.initHibernateContainer(runtimeClassloader);
        Environment.addService(IBeanContainer.class, BeanContainer.instance());

        return beanClasses;
    }

    protected static void generateJarFile(String jarFile) {
        /** ant script to start the hibernatetool 'hbm2java' */
        final String HIBTOOLNAME = "hibtool.xml";
        /** hibernate reverse engeneer configuration */
        final String HIBREVNAME = "hibernate.reveng.xml";
        Properties properties = new Properties();
        properties.setProperty(HIBREVNAME, Environment.getConfigPath() + HIBREVNAME);
//    properties.setProperty("hbm.conf.xml", "hibernate.conf.xml");
        properties.setProperty("server.db-config.file", Persistence.FILE_JDBC_PROP_FILE);
        properties.setProperty("dest.file", jarFile);

        String plugin_dir = System.getProperty("user.dir");
        properties.setProperty("plugin.dir", new File(plugin_dir).getAbsolutePath());
        if (plugin_dir.endsWith(".jar/")) {
            properties.setProperty("plugin_isjar", Boolean.toString(true));
        }
        Environment.get(CompatibilityLayer.class).runRegistered("ant",
            Environment.getConfigPath() + HIBTOOLNAME,
            "create.bean.jar",
            properties);
    }

    protected void reset() {
        String configPath = Environment.get(Environment.KEY_CONFIG_PATH, "config");

        sessions.clear();
        Environment.reset();
        Environment.setProperty(Environment.KEY_CONFIG_PATH, configPath);
        Environment.setProperty("http.serviceURL", serviceURL.toString());
        BeanDefinition.clearCache();
        BeanValue.clearCache();
        Thread.currentThread().setContextClassLoader(appstartClassloader);
        createPageBuilder();
        builder = Environment.get(IPageBuilder.class);
    }

//    /**
//     * createTestNavigationModel
//     * 
//     * @return navigation model for testing purpose
//     */
//    static Stack<BeanDefinition<?>> createTestNavigationModel() {
//
//        BeanContainer.initEmtpyServiceActions();
//
//        TypeBean b = new TypeBean();
//        b.setDate(new Date());
//        b.setString("test");
//        b.setBigDecimal(new BigDecimal(10));
//        Bean<TypeBean> bean = new Bean<TypeBean>();
//        final Collection<TypeBean> rootBeanList = new ArrayList(Arrays.asList(b));
//        BeanCollector<Collection<TypeBean>, TypeBean> root = new BeanCollector<Collection<TypeBean>, TypeBean>(TypeBean.class,
//            true,
//            true,
//            false);
//        BeanFinder<TypeBean, Object> beanFinder = new BeanFinder<TypeBean, Object>(TypeBean.class) {
//            @Override
//            public Collection<TypeBean> getData(Object fromFilter, Object toFilter) {
//                return rootBeanList;
//            }
//        };
//        beanFinder.setDetailBean(bean);
//        root.setBeanFinder(beanFinder);
//        final Bean<Object> model = new Bean<Object>();
//        model.addAttribute("Name", "Stefan", RegularExpressionFormat.createAlphaNumRegExp(15, true), null, null);
//        model.addAttribute("Kategorie", 1, null, null, null)
//            .setRange(Arrays.asList(1, 2, 3))
//            .setBasicDef(3, false, null, null, "Kategorie");
//        model.addAction(new CommonAction<Object>("testid", "+xxx", null) {
//            @Override
//            public Object action() throws Exception {
//                String newValue = model.getValue("Name") + "xxx";
//                model.setValue("Name", newValue);
//                return model;
//            }
//        });
////        model.addDefaultSaveAction();
//
//        Bean appStart = new Bean();
//        appStart.setName(START_PAGE);
//
//        Stack<BeanDefinition<?>> navigationModel = new Stack<BeanDefinition<?>>();
//        navigationModel.push(appStart);
//        navigationModel.push(root);
//        navigationModel.push(model);
//        return navigationModel;
//    }
}
